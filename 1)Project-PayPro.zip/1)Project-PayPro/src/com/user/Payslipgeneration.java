package com.user;
import java.util.*;

import com.model.Employee;
import com.service.SalaryCalculation1;


public class Payslipgeneration {
	public static void main(String[] args) {
		
		Scanner scanner=new Scanner(System.in);
		
		System.out.println("Enter Employee Id : ");
        int id=scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter Employee Name : ");
        String name=scanner.nextLine();
        System.out.println("Enter Date : ");
        String date=scanner.nextLine();
        
        
        Employee e=new Employee();
        e.setEid(id);
        e.setEname(name);
        e.setEdep("Developer");
        e.setEworkingday("26");
        e.setBasicsalary(30000d);
        e.setHomeallowance(2000d);
        e.setTrasnsportallowance(1000d);
        e.setDeduction(300);
        e.setDy(date);
        
        System.out.println("Enter Overtime Hours: ");
        double oth=scanner.nextDouble();
        System.out.println("Enter Leaves: ");
        double leaves=scanner.nextDouble();
        
        //call cnt(static method this method return net salary.(logic write in cnt method)
        double netSalary=SalaryCalculation1.cnt(e,oth,leaves);
   
        System.out.println("_______________<<MICROSOFT AZURE>>________________");
        System.out.println("Employee Personal Details:");
        System.out.println("Date: "+e.getDy());
        System.out.println("Employee Name: "+e.getEname());
        System.out.println("Employee Id:"+e.getEid());
        System.out.println("Employee Department:"+e.getEdep());
        System.out.println("---------------------------------------------------");
        System.out.println("| No|"+"        Index"+"               |"+"    Info");
        System.out.println("---------------------------------------------------");
        System.out.println("| 1)|"+"   Employee Department :    |"+e.getEdep());
        System.out.println("| 2)|"+"   Basic Salary:            |"+e.getBasicsalary());
        System.out.println("| 3)|"+"   Employee Working Days:   |"+e.getEworkingday());
        System.out.println("| 4)|"+"   Leaves :                 |"+leaves);
        System.out.println("| 5)|"+"   Basic Salary :           |"+e.getBasicsalary());
        System.out.println("| 6)|"+"   Home Allowance :         |"+e.getHomeallowance());
        System.out.println("| 7)|"+"   Transport Allowance :    |"+e.getTransportallowance());
        System.out.println("| 8)|"+"   Overtime Pay :           |"+e.getBasicsalary()/230*oth);
        System.out.println("| 9)|"+"   Other Deduction :        |"+(e.getDeduction()));
        System.out.println("|10)|"+"   Leaves Deduction :       |"+(e.getBasicsalary()/26*leaves));
        System.out.println("|11)|"+"   Tax:                     |"+(0.12*e.getBasicsalary()));
        System.out.println("---------------------------------------------------");
        System.out.println("|12)|"+"   Net Salary :             |"+netSalary);
        System.out.println("___________________________________________________");
        
	}
}
      
