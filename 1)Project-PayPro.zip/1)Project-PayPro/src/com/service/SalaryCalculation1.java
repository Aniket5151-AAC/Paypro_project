package com.service;

import com.model.Employee;

public class SalaryCalculation1 {
	//static method created
     public static double cnt(Employee employee,double oth,double leaves) {
    	 //create employee class object
     double basicSalary=employee.getBasicsalary();
     double homeallowances=employee.getHomeallowance();
     double transportallowances=employee.getTransportallowance();
     double deductions=employee.getDeduction();
     
     double otpr=basicSalary /230;
     double otp=oth*otpr;
     
     double grossSalary=basicSalary + homeallowances + transportallowances + otp;
    
     double leaveDeduction=basicSalary /26 * leaves;
     
     double totalDeductions= deductions;
     
     double tax=0.18 * basicSalary;
     
     double netSalary=grossSalary - totalDeductions-tax- leaveDeduction;
     return netSalary;
     }    
     
}
