package com.model;

public class Employee {
	private int eid;
	private String ename;
	private String edep;
	private String eworkingday;
	private String dy;
	private double trasportallowance;
	private double basicsalary;
	private double homeallowance;
	private double deduction;
	
	public void setEid(int eid) {
		this.eid=eid;
	}
	public void setEname(String ename) {
		this.ename=ename;
	}
	public void setEdep(String edep) {
		this.edep=edep;
	}
	public void setEworkingday(String eworkingday) {
		this.eworkingday=eworkingday;
	}
	public void setDy(String dy) {
		this.dy=dy;
	}
	public void setTrasnsportallowance(double transportallowance) {
		this.trasportallowance=transportallowance;
	}
	public void setBasicsalary(double basicsalary) {
		this.basicsalary=basicsalary;
	}
	public void setHomeallowance(double homeallowance) {
		this.homeallowance=homeallowance;
	}
	public void setDeduction(double deduction) {
		this.deduction=deduction;
	}
	public int getEid() {
		return eid;
	}
	public String getEname() {
		return ename;
	}
	public String getEdep() {
		return edep;
	}
	public String getEworkingday() {
		return eworkingday;
	}
	public String getDy() {
		return dy;
	}
	public double getTransportallowance() {
	    return trasportallowance;
	}
	public double getBasicsalary() {
		return basicsalary;
	}
	public double getHomeallowance() {
		return homeallowance;
	}
	public double getDeduction() {
		return deduction;
	
	}
}
